import React from 'react'
import { ResetPassword } from '../features/auth/components/ResetPassword'

export const ResetPasswordPage = () => {
  return (
    <ResetPassword/>
  )
}
